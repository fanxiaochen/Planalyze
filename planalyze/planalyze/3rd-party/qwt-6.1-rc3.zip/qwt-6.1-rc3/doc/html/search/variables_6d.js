var searchData=
[
  ['modifiers',['modifiers',['../class_qwt_event_pattern_1_1_mouse_pattern.html#ad12c724aac7bba9f16540c604dc108f9',1,'QwtEventPattern::MousePattern::modifiers()'],['../class_qwt_event_pattern_1_1_key_pattern.html#a1db88ed291d4ba49fa84e32e86fa10d1',1,'QwtEventPattern::KeyPattern::modifiers()']]]
];
