var searchData=
[
  ['install',['INSTALL',['../qwtinstall.html',1,'']]]
];
